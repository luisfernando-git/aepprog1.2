package academico;

/**
* @author Luis Fernando Gon�alves e Hudson Cabral
*/

public class Aluno {
	
	private String nome;
	
	private int ra;
	
	public Aluno(int ra, String nome) {
		this.nome = nome;
		this.ra = ra;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public float getRA() {
		return this.ra;
	}
}
