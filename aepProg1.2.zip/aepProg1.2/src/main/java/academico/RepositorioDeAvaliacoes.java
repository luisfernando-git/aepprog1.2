package academico;

/**
* @author Luis Fernando Gon�alves e Hudson Cabral
*/

import java.util.ArrayList;
import java.util.List;

public class RepositorioDeAvaliacoes {
	
	private List<Avaliacao> avaliacoes = new ArrayList<Avaliacao>();
	
	public void adicionar(Avaliacao avaliacao) {
		this.avaliacoes.add(avaliacao);
	}
	
    public ArrayList obterAprovados(Disciplina disciplina){
        int contador = 0;
        Avaliacao aux;
        ArrayList aprovados = new ArrayList();
        while(contador < this.avaliacoes.size()){
            for(int contador2 = 0 ; contador2 <=4 ; contador2++) {
            	
            }
            contador++;
        }
        return aprovados;
    }		
}