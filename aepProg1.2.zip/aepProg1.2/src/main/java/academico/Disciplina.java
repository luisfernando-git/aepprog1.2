package academico;

/**
* @author Luis Fernando Gon�alves e Hudson Cabral
*/

public class Disciplina {
	
	private String nome;
	
	public Disciplina(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return this.nome;
	}
}
